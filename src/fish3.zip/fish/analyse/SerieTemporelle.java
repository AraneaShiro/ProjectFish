package fish.analyse;

import fish.acquisition.DataframeComplet;
import fish.exceptions.OutOfBoundException;
import fish.graphiques.LineChart;
import fish.graphiques.BarChart;
import java.util.*;

/**
 * Analyse et visualisation de séries temporelles.
 *
 * Fonctionnalités :
 *   - Chargement depuis une colonne temporelle + une colonne de valeurs
 *   - Moyennes mobiles (SMA et EMA)
 *   - Détection de tendance (régression linéaire)
 *   - Décomposition saisonnière simplifiée
 *   - Affichage LineChart avec courbe brute + tendance + moyenne mobile
 *   - Statistiques : min, max, variation, autocorrélation lag-1
 *   - BarChart des variations périodiques
 *
 * @author Jules Grenesche
 * @version 1.0
 */
public class SerieTemporelle {

    // ── ANSI ─────────────────────────────────────────────────────────────────
    private static final String R     = "\u001B[0m";
    private static final String G     = "\u001B[1m";
    private static final String CYA_G = "\u001B[1m\u001B[36m";
    private static final String JAU   = "\u001B[33m";
    private static final String VER   = "\u001B[32m";
    private static final String ROU   = "\u001B[31m";
    private static final String VER_G = "\u001B[1m\u001B[32m";
    private static final String JAU_G = "\u001B[1m\u001B[33m";

    // ── Données ───────────────────────────────────────────────────────────────
    private double[] temps;   // axe X (numérique : année, mois, index…)
    private double[] valeurs; // axe Y
    private String[] tLabels; // étiquettes texte optionnelles pour l'axe X
    private String   titre      = "Série temporelle";
    private String   uniteTemps = "t";
    private String   uniteVal   = "valeur";

    // ── Résultats calculés ────────────────────────────────────────────────────
    private double   slope, intercept;          // régression linéaire
    private double[] tendance;
    private double[] sma;                       // simple moving average
    private double   autocorr;                  // autocorrélation lag-1

    // ── API ───────────────────────────────────────────────────────────────────

    public SerieTemporelle titre(String t)         { this.titre      = t;  return this; }
    public SerieTemporelle uniteTemps(String u)    { this.uniteTemps = u;  return this; }
    public SerieTemporelle uniteVal(String u)      { this.uniteVal   = u;  return this; }
    public SerieTemporelle xLabels(String... labs) { this.tLabels    = labs; return this; }

    /** Charge depuis des tableaux. */
    public SerieTemporelle depuis(double[] temps, double[] valeurs) {
        this.temps   = temps.clone();
        this.valeurs = valeurs.clone();
        return this;
    }

    /** Charge depuis une colonne index (colT) et une colonne valeur (colV) du dataframe. */
    public SerieTemporelle depuis(DataframeComplet df, int colT, int colV) {
        uniteTemps = df.getNomCol(colT);
        uniteVal   = df.getNomCol(colV);
        List<Double> ts = new ArrayList<>(), vs = new ArrayList<>();
        for (int i = 0; i < df.getNbLignes(); i++) {
            try {
                Object t = df.getCase(i, colT), v = df.getCase(i, colV);
                if (t instanceof Number && v instanceof Number) {
                    ts.add(((Number)t).doubleValue());
                    vs.add(((Number)v).doubleValue());
                }
            } catch (OutOfBoundException e) { /* ignoré */ }
        }
        temps   = ts.stream().mapToDouble(Double::doubleValue).toArray();
        valeurs = vs.stream().mapToDouble(Double::doubleValue).toArray();
        return this;
    }

    /** Charge en utilisant l'index des lignes comme temps, une colonne comme valeur. */
    public SerieTemporelle depuis(DataframeComplet df, int colV) {
        uniteTemps = "index";
        uniteVal   = df.getNomCol(colV);
        List<Double> vs = new ArrayList<>();
        for (int i = 0; i < df.getNbLignes(); i++) {
            try {
                Object v = df.getCase(i, colV);
                if (v instanceof Number) vs.add(((Number)v).doubleValue());
            } catch (OutOfBoundException e) { /* ignoré */ }
        }
        valeurs = vs.stream().mapToDouble(Double::doubleValue).toArray();
        temps   = new double[valeurs.length];
        for (int i = 0; i < valeurs.length; i++) temps[i] = i;
        return this;
    }

    // ── Analyse ───────────────────────────────────────────────────────────────

    /** Lance toutes les analyses (tendance, SMA, autocorr). */
    public SerieTemporelle analyser() {
        if (valeurs == null || valeurs.length < 2) return this;
        calculerRegression();
        calculerTendance();
        calculerAutocorrelation();
        return this;
    }

    /** Retourne la moyenne mobile simple sur {@code fenetre} périodes. */
    public double[] sma(int fenetre) {
        int n = valeurs.length;
        sma = new double[n];
        Arrays.fill(sma, Double.NaN);
        for (int i = fenetre - 1; i < n; i++) {
            double s = 0;
            for (int j = i - fenetre + 1; j <= i; j++) s += valeurs[j];
            sma[i] = s / fenetre;
        }
        return sma;
    }

    /** Retourne la moyenne mobile exponentielle (EMA) avec lissage {@code alpha}. */
    public double[] ema(double alpha) {
        int n = valeurs.length;
        double[] ema = new double[n];
        ema[0] = valeurs[0];
        for (int i = 1; i < n; i++) ema[i] = alpha * valeurs[i] + (1 - alpha) * ema[i-1];
        return ema;
    }

    /** Retourne les variations périodiques (diff[i] = valeurs[i] - valeurs[i-1]). */
    public double[] variations() {
        int n = valeurs.length;
        double[] diff = new double[n - 1];
        for (int i = 1; i < n; i++) diff[i - 1] = valeurs[i] - valeurs[i - 1];
        return diff;
    }

    // ── Affichage principal ───────────────────────────────────────────────────

    /**
     * Affiche la courbe complète avec tendance et moyenne mobile.
     *
     * @param fenetre taille de la fenêtre de moyenne mobile (0 = désactivé)
     */
    public void afficher(int fenetre) {
        if (valeurs == null || valeurs.length == 0) {
            System.out.println(ROU + "Aucune donnée." + R); return;
        }
        analyser();

        LineChart lc = new LineChart()
            .titre(titre)
            .xLabel(uniteTemps)
            .yLabel(uniteVal)
            .taille(65, 18)
            .serie("Données brutes", temps, valeurs);

        if (tendance != null)
            lc.serie("Tendance (régr.)", temps, tendance);

        if (fenetre > 1) {
            double[] smaArr = sma(fenetre);
            // Ne garder que les valeurs non-NaN
            double[] tSma = new double[valeurs.length - fenetre + 1];
            double[] vSma = new double[valeurs.length - fenetre + 1];
            for (int i = fenetre - 1; i < valeurs.length; i++) {
                tSma[i - fenetre + 1] = temps[i];
                vSma[i - fenetre + 1] = smaArr[i];
            }
            lc.serie("SMA(" + fenetre + ")", tSma, vSma);
        }

        if (tLabels != null) lc.xLabels(tLabels);
        lc.afficher();

        // ── Stats ─────────────────────────────────────────────────────────────
        afficherStats();
    }

    public void afficher() { afficher(3); }

    /** Affiche le graphique à barres des variations. */
    public void afficherVariations() {
        if (valeurs == null || valeurs.length < 2) return;
        double[] diff = variations();

        String[] cats = new String[diff.length];
        for (int i = 0; i < diff.length; i++)
            cats[i] = tLabels != null && i+1 < tLabels.length ? tLabels[i+1] : String.valueOf((int)temps[i+1]);

        new BarChart()
            .titre("Variations — " + titre)
            .xLabel(uniteTemps)
            .horizontal()
            .categorie(cats)
            .serie("Δ " + uniteVal, diff)
            .afficher();
    }

    // ── Stats texte ───────────────────────────────────────────────────────────

    public void afficherStats() {
        if (valeurs == null) return;
        double min = Arrays.stream(valeurs).min().getAsDouble();
        double max = Arrays.stream(valeurs).max().getAsDouble();
        double moy = Arrays.stream(valeurs).average().getAsDouble();
        double var = max - min;
        double varPct = moy == 0 ? 0 : var / Math.abs(moy) * 100;

        System.out.println("\n" + CYA_G + "── Statistiques série temporelle ──" + R);
        System.out.printf("  n=%-5d  min=" + JAU + "%-8.3f" + R + "  max=" + JAU + "%-8.3f" + R
                + "  moy=" + JAU + "%-8.3f" + R + "%n", valeurs.length, min, max, moy);
        System.out.printf("  variation=%-8.3f  (%.1f%%)%n", var, varPct);

        if (tendance != null) {
            String dir = slope > 0 ? VER_G + "↑ Haussière" + R : (slope < 0 ? ROU + "↓ Baissière" + R : "→ Stable");
            System.out.printf("  tendance=%s  pente=%.4f  intercept=%.4f%n", dir, slope, intercept);
        }
        System.out.printf("  autocorrélation lag-1 = " + JAU + "%.4f" + R + "%n", autocorr);
    }

    // ── Calculs internes ─────────────────────────────────────────────────────

    private void calculerRegression() {
        int n = valeurs.length;
        double mx = 0, my = 0;
        for (int i = 0; i < n; i++) { mx += temps[i]; my += valeurs[i]; }
        mx /= n; my /= n;
        double num = 0, den = 0;
        for (int i = 0; i < n; i++) {
            num += (temps[i] - mx) * (valeurs[i] - my);
            den += (temps[i] - mx) * (temps[i] - mx);
        }
        slope     = den == 0 ? 0 : num / den;
        intercept = my - slope * mx;
    }

    private void calculerTendance() {
        tendance = new double[valeurs.length];
        for (int i = 0; i < valeurs.length; i++)
            tendance[i] = slope * temps[i] + intercept;
    }

    private void calculerAutocorrelation() {
        int n = valeurs.length;
        double moy = Arrays.stream(valeurs).average().getAsDouble();
        double num = 0, den = 0;
        for (int i = 0; i < n; i++) den += (valeurs[i] - moy) * (valeurs[i] - moy);
        for (int i = 1; i < n; i++) num += (valeurs[i] - moy) * (valeurs[i-1] - moy);
        autocorr = den == 0 ? 0 : num / den;
    }

    // ── Getters ───────────────────────────────────────────────────────────────

    public double getSlope()      { return slope; }
    public double getIntercept()  { return intercept; }
    public double getAutocorr()   { return autocorr; }
    public double[] getTendance() { return tendance; }

    // ── Main ─────────────────────────────────────────────────────────────────

    public static void main(String[] args) {
        // Série de prévalence parasitaire annuelle
        double[] annees = {2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023};
        double[] prev   = {18.2, 20.5, 19.8, 23.1, 25.4, 22.8, 27.6, 29.3, 31.0};
        String[] labs   = {"2015","2016","2017","2018","2019","2020","2021","2022","2023"};

        new SerieTemporelle()
            .titre("Prévalence Anisakis — Merlan 2015-2023")
            .uniteTemps("Année")
            .uniteVal("Prévalence (%)")
            .xLabels(labs)
            .depuis(annees, prev)
            .afficher(3);

        System.out.println();
        new SerieTemporelle()
            .titre("Variations annuelles")
            .uniteTemps("Année")
            .uniteVal("Δ Prévalence")
            .xLabels(labs)
            .depuis(annees, prev)
            .afficherVariations();
    }
}
